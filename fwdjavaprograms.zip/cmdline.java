import java.io.*;

public class cmdline
{
	public static void main(String args[])
	{
		int n=args.length;
		for(int i=0;i<n;i++)
			System.out.println("JAVA IS "+args[i]);
	}
}

